/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'motion/react';
import { 
  Rocket, 
  Terminal as TerminalIcon, 
  X, 
  Cpu, 
  Flame, 
  Cloud, 
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
  Zap,
  DollarSign,
  Search,
  MessageSquare,
  Copy,
  ChevronDown,
  ArrowUpRight,
  ExternalLink,
  History,
  Filter,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  MoreHorizontal,
  Plus,
  Minimize2,
  Maximize2,
  Command,
  Activity,
  Box,
  Layers,
  Database,
  Globe,
  RefreshCw,
  Eye,
  TrendingDown,
  TrendingUp,
  LayoutGrid
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

// --- Types ---
type AlertLevel = 'CRITICAL' | 'WATCH' | 'FYI';

interface Alert {
  id: string;
  level: AlertLevel;
  title: string;
  tool: string;
  summary: string;
  impact_level: AlertLevel;
  dollar_impact: number;
  action: string;
  source_url: string;
  urgency_days: number;
  details?: string;
  checklist?: string[];
}

interface StackItem {
  id: string;
  name: string;
  category: string;
  cost: number;
  health: number;
  icon: React.ReactNode;
}

interface FloatingWindow {
  id: string;
  title: string;
  content: React.ReactNode;
  x: number;
  y: number;
  zIndex: number;
}

// --- AI Initialization ---
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const CountUp = ({ value, prefix = "$", suffix = "" }: { value: number, prefix?: string, suffix?: string }) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    let start = 0;
    const end = value;
    if (start === end) return;
    let totalFrames = 60;
    let frame = 0;
    const timer = setInterval(() => {
      frame++;
      const progress = frame / totalFrames;
      setCount(Math.floor(end * progress));
      if (frame === totalFrames) clearInterval(timer);
    }, 16);
    return () => clearInterval(timer);
  }, [value]);
  return <span>{prefix}{count.toLocaleString()}{suffix}</span>;
};

const ScrambleText = ({ text, duration = 800, delay = 0, className = "" }: { text: string, duration?: number, delay?: number, className?: string }) => {
  const [displayText, setDisplayText] = useState('');
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%';
  
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    let interval: NodeJS.Timeout;

    timeout = setTimeout(() => {
      let iterations = 0;
      interval = setInterval(() => {
        setDisplayText(
          text
            .split('')
            .map((char, i) => {
              if (i < Math.floor(iterations)) return char;
              return chars[Math.floor(Math.random() * chars.length)];
            })
            .join('')
        );

        if (iterations >= text.length) {
          clearInterval(interval);
        }
        iterations += text.length / (duration / 30);
      }, 30);
    }, delay);

    return () => {
      clearTimeout(timeout);
      clearInterval(interval);
    };
  }, [text, duration, delay]);

  return <span className={className}>{displayText}</span>;
};

// --- Components ---

const ParticleBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: { x: number; y: number; vx: number; vy: number; r: number }[] = [];
    const particleCount = 65;
    let mouse = { x: -1000, y: -1000 };

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const init = () => {
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          r: 1.5
        });
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = 'rgba(0, 229, 255, 0.04)';
      ctx.strokeStyle = 'rgba(0, 229, 255, 0.04)';

      particles.forEach((p, i) => {
        // Drift toward mouse
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 180) {
          p.vx += dx * 0.0003;
          p.vy += dy * 0.0003;
        }

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.sqrt((p.x - p2.x) ** 2 + (p.y - p2.y) ** 2);
          if (dist < 120) {
            ctx.globalAlpha = (1 - dist / 120) * 0.06;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
            ctx.globalAlpha = 1;
          }
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouse = { x: e.clientX, y: e.clientY };
    };

    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', handleMouseMove);

    resize();
    init();
    draw();

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" />;
};

const IntroCinematic = ({ onComplete }: { onComplete: () => void }) => {
  const [snippets, setSnippets] = useState<string[]>([]);
  const fullSnippets = [
    "initializing stack scan...",
    "const alerts = await claude.search(stack)",
    "web_search: vertex ai pricing changelog...",
    "⚡ detected: gemini flash -40% cost",
    "✅ 2 critical findings — loading dashboard"
  ];

  useEffect(() => {
    let timers: NodeJS.Timeout[] = [];
    fullSnippets.forEach((text, i) => {
      timers.push(setTimeout(() => {
        setSnippets(prev => [...prev, text]);
      }, 300 + i * 450));
    });

    const endTimer = setTimeout(onComplete, 3500);
    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(endTimer);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[200] bg-void flex items-center justify-center overflow-hidden">
      <button 
        onClick={onComplete}
        className="absolute top-8 right-8 text-[12px] font-sans text-text-secondary hover:text-text-primary z-10"
      >
        skip intro →
      </button>

      {/* Car Sequence */}
      <motion.div
        initial={{ left: -150 }}
        animate={{ left: '100vw' }}
        transition={{ duration: 2.2, ease: "easeInOut", delay: 0.1 }}
        className="absolute h-24 w-[120px] flex items-center z-20"
        style={{ top: '50%', transform: 'translateY(-50%)' }}
      >
        {/* Car SVG */}
        <svg width="120" height="40" viewBox="0 0 120 40" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 25H110L105 15H25L15 20L10 25Z" stroke="#00E5FF" strokeWidth="1.5" />
          <circle cx="30" cy="30" r="5" stroke="#00E5FF" strokeWidth="1.5" />
          <circle cx="90" cy="30" r="5" stroke="#00E5FF" strokeWidth="1.5" />
          <path d="M25 15L35 5H85L95 15H25Z" stroke="#00E5FF" strokeWidth="1.5" strokeOpacity="0.5" />
        </svg>
        
        {/* Glowing Trail */}
        <div className="absolute right-[95%] h-[1px] w-[200vw] bg-gradient-to-l from-accent-cyan/80 to-transparent" />
      </motion.div>

      {/* Terminal Output Following Trail */}
      <div className="absolute inset-x-0 top-1/2 mt-8 flex flex-col items-center">
        <div className="space-y-1">
          {snippets.map((text, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-accent-green/70 font-mono text-[11px] h-4"
            >
              {text}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

const Onboarding = ({ onComplete }: { onComplete: (stack: string, fear: string) => void }) => {
  const [stack, setStack] = useState('');
  const [fear, setFear] = useState('');
  const [placeholder, setPlaceholder] = useState('');
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const placeholders = [
    "We use Vertex AI for inference, Firebase for auth, Cohere for embeddings, Cloud Run for deployment. Monthly spend: ~$1,200.",
    "We're on Next.js, Vercel, Supabase, and Stripe. Just added Pinecone. Monthly spend: ~$800.",
    "Stack: OpenAI GPT-4o, AWS Lambda, RDS Postgres, Twilio for SMS. Spend: ~$2,100/mo.",
    "Running LangChain on GCP, Weaviate vector DB, Cloudflare Workers, Resend for email."
  ];

  useEffect(() => {
    const text = placeholders[placeholderIndex];
    const speed = isDeleting ? 14 : 28;
    
    const timer = setTimeout(() => {
      if (!isDeleting) {
        setPlaceholder(text.slice(0, placeholder.length + 1));
        if (placeholder === text) {
          setTimeout(() => setIsDeleting(true), 2200);
        }
      } else {
        setPlaceholder(text.slice(0, placeholder.length - 1));
        if (placeholder === '') {
          setIsDeleting(false);
          setPlaceholderIndex((prev) => (prev + 1) % placeholders.length);
        }
      }
    }, speed);

    return () => clearTimeout(timer);
  }, [placeholder, isDeleting, placeholderIndex]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl w-full mx-auto p-12 space-y-12 z-10"
    >
      <div className="space-y-4">
        <h2 className="text-4xl font-display font-medium tracking-tight">Detect your infrastructure.</h2>
        <p className="text-text-secondary text-sm">Tell StackSense about your stack, cloud providers, and monthly spend.</p>
      </div>

      <div className="space-y-8">
        <div className="relative">
          <textarea
            value={stack}
            onChange={(e) => setStack(e.target.value)}
            className="w-full h-40 bg-[#020810] border border-border focus:border-accent-cyan/40 p-6 rounded-xl text-text-primary placeholder:text-text-muted focus:ring-0 transition-all resize-none font-sans"
            placeholder={placeholder}
          />
          <div className="absolute top-4 right-4 animate-pulse">
            <Activity className="text-accent-cyan/20" size={20} />
          </div>
        </div>

        <div className="space-y-4">
          <label className="text-[10px] mono-data text-text-muted uppercase tracking-[0.2em]">Biggest concern this week?</label>
          <input
            type="text"
            value={fear}
            onChange={(e) => setFear(e.target.value)}
            className="w-full bg-[#020810] border border-border focus:border-accent-cyan/40 p-4 rounded-xl text-text-primary placeholder:text-text-muted focus:ring-0 transition-all font-sans"
            placeholder="e.g. cost spikes, breaking changes, API deprecation..."
          />
        </div>

        <button
          onClick={() => onComplete(stack, fear)}
          disabled={!stack}
          className="w-full py-4 bg-accent-cyan/10 border border-accent-cyan border-dashed text-accent-cyan font-display font-bold uppercase tracking-widest hover:bg-accent-cyan hover:text-void transition-all disabled:opacity-30 disabled:cursor-not-allowed group"
        >
          Initialize intelligence audit
          <ChevronRight className="inline-block ml-2 group-hover:translate-x-1 transition-transform" size={18} />
        </button>
      </div>
    </motion.div>
  );
};

const ECGHeartbeat = () => (
  <svg width="80" height="24" viewBox="0 0 80 24" className="text-accent-cyan overflow-visible">
    <motion.polyline
      points="0,12 20,12 24,4 28,20 32,12 52,12 56,4 60,20 64,12 80,12"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      className="animate-ecg"
    />
    <motion.polyline
      points="80,12 100,12 104,4 108,20 112,12 132,12 136,4 140,20 144,12 160,12"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      className="animate-ecg"
    />
  </svg>
);

const ArcGauge = ({ value, label, subLabel }: { value: number; label: string; subLabel: string }) => {
  const dashArray = 220 * Math.PI;
  const dashOffset = dashArray * (1 - (value / 100) * 0.5); // Semi-circle
  
  const color = value < 30 ? 'var(--color-accent-red)' : value < 60 ? 'var(--color-accent-amber)' : 'var(--color-accent-green)';

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-[220px] h-[120px]">
        <svg width="220" height="120" viewBox="0 0 220 120">
          <path
            d="M 20 110 A 90 90 0 0 1 200 110"
            fill="none"
            stroke="rgba(0, 229, 255, 0.08)"
            strokeWidth="14"
            strokeLinecap="round"
          />
          <motion.path
            d="M 20 110 A 90 90 0 0 1 200 110"
            fill="none"
            stroke={color}
            strokeWidth="14"
            strokeLinecap="round"
            strokeDasharray={dashArray}
            initial={{ strokeDashoffset: dashArray }}
            animate={{ strokeDashoffset: dashOffset }}
            transition={{ duration: 1.2, delay: 0.4, ease: [0.34, 1.56, 0.64, 1] }}
          />
          {/* Milestone markers */}
          {[25, 50, 75].map((m) => {
            const angle = (m / 100) * 180 + 180;
            const x = 110 + 100 * Math.cos((angle * Math.PI) / 180);
            const y = 110 + 100 * Math.sin((angle * Math.PI) / 180);
            return <circle key={m} cx={x} cy={y} r="2" fill="var(--color-text-muted)" />;
          })}
        </svg>

        <div className="absolute inset-0 flex flex-col items-center justify-end pb-2">
          <div className="font-mono text-3xl text-text-primary font-bold overflow-hidden h-9">
             <CountUp value={4080} />
          </div>
          <span className="text-[10px] mono-data text-text-muted uppercase tracking-[0.2em]">{subLabel}</span>
        </div>
      </div>
    </div>
  );
};

const AlertCard: React.FC<{ alert: Alert; index: number; onOpenDetail: (alert: Alert) => void }> = ({ alert, index, onOpenDetail }) => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const severityColor = alert.impact_level === 'CRITICAL' ? 'var(--color-accent-red)' : alert.impact_level === 'WATCH' ? 'var(--color-accent-amber)' : 'var(--color-accent-green)';
  const pulseClass = alert.impact_level === 'CRITICAL' ? 'animate-pulse' : '';

  return (
    <div className="perspective-1000">
      <motion.div
        initial={{ opacity: 0, y: 24, rotateX: 12, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
        transition={{ delay: index * 0.16, duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
        className="relative bg-surface border border-border p-8 hover:bg-elevated hover:border-accent-cyan/30 transition-all duration-300 group cursor-default"
      >
        <div className="absolute left-0 top-0 bottom-0 w-[3px] transition-all group-hover:w-[4px]" style={{ backgroundColor: severityColor }} />
        
        <div className="flex justify-between items-start mb-6">
          <div className="flex items-center gap-3">
             <div className={`w-2 h-2 rounded-full ${pulseClass}`} style={{ backgroundColor: severityColor }} />
             <span className="mono-data text-[10px] font-bold tracking-widest" style={{ color: severityColor }}>
               {alert.impact_level}
             </span>
          </div>
          <div className="text-[10px] mono-data text-text-muted flex items-center gap-4">
            <span>{alert.tool}</span>
            <span>•</span>
            <span>APR 27</span>
          </div>
        </div>

        <h3 className="text-xl font-medium mb-2 tracking-tight group-hover:text-accent-cyan transition-colors">{alert.title}</h3>
        <p className="text-sm text-text-secondary leading-relaxed mb-6 line-clamp-2">{alert.summary}</p>

        <div className="flex items-end justify-between mb-8">
           <div className="space-y-1">
             <span className="text-[9px] mono-data text-text-muted uppercase tracking-widest">Est. Impact</span>
             <div className="text-2xl font-mono text-accent-amber font-bold">
               Save ~<CountUp value={alert.dollar_impact} />/mo
             </div>
           </div>
           {alert.urgency_days < 21 && (
             <div className="px-3 py-1 bg-accent-red/10 border border-accent-red/20 text-[10px] mono-data text-accent-red uppercase font-bold tracking-widest">
               Act within {alert.urgency_days} days
             </div>
           )}
        </div>

        <div className="flex items-center gap-4 pt-6 border-t border-border">
          <button 
            onClick={() => setIsChatOpen(!isChatOpen)}
            className="flex-1 py-3 bg-accent-cyan/10 border border-accent-cyan/30 text-accent-cyan text-[10px] mono-data uppercase font-bold tracking-widest hover:bg-accent-cyan hover:text-void transition-all hover-shimmer"
          >
            Ask Claude
          </button>
          <button 
            onClick={() => onOpenDetail(alert)}
            className="flex-1 py-3 border border-border text-text-secondary text-[10px] mono-data uppercase font-bold tracking-widest hover:border-accent-cyan/40 hover:text-text-primary transition-all"
          >
            Expand Details
          </button>
        </div>

        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-6 pt-6 border-t border-border space-y-4">
                <div className="flex items-center gap-2 mb-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-accent-cyan" />
                   <span className="text-[10px] mono-data text-text-muted uppercase tracking-widest">StackPulse v4.2 Contextual</span>
                </div>
                <div className="bg-void p-4 rounded-lg border border-border text-sm text-text-secondary leading-relaxed italic">
                  "I've analyzed your Vertex AI usage. Migrating to the Flash models is straightforward. You only need to update the endpoint string in your edge functions. Shall I generate a migration script?"
                </div>
                <div className="flex gap-2">
                  <input 
                    autoFocus
                    placeholder="Ask about technical requirements..." 
                    className="flex-1 bg-[#020810] border border-border p-3 text-xs placeholder:text-text-muted focus:ring-0 focus:border-accent-cyan/40 transition-all rounded-lg"
                  />
                  <button className="px-4 bg-surface border border-border hover:border-accent-cyan/40 text-accent-cyan transition-all rounded-lg">
                    <ArrowUpRight size={16} />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [view, setView] = useState<'INTRO' | 'ONBOARDING' | 'DASHBOARD'>('INTRO');
  const [isScanning, setIsScanning] = useState(false);
  const [scanLines, setScanLines] = useState<{ text: string; status: 'INFO' | 'ALERT' | 'SUCCESS' }[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [stackData, setStackData] = useState<StackItem[]>([]);
  const [windows, setWindows] = useState<FloatingWindow[]>([]);
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [inspectorOpen, setInspectorOpen] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [lastScanned, setLastScanned] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setLastScanned(prev => prev + 1), 60000);
    return () => clearInterval(timer);
  }, []);

  const handleOnboardingComplete = async (stack: string, fear: string) => {
    setView('DASHBOARD');
    // Simulated detection delay
    setTimeout(() => {
      setStackData([
        { id: '1', name: 'Vertex AI', category: 'Inference', cost: 600, health: 72, icon: <Cpu size={14} /> },
        { id: '2', name: 'Firebase', category: 'Database', cost: 120, health: 94, icon: <Flame size={14} /> },
        { id: '3', name: 'Cloud Run', category: 'Compute', cost: 85, health: 88, icon: <Cloud size={14} /> },
        { id: '4', name: 'Pinecone', category: 'Vector DB', cost: 150, health: 91, icon: <Box size={14} /> },
        { id: '5', name: 'Stripe', category: 'Payments', cost: 45, health: 98, icon: <Database size={14} /> }
      ]);
    }, 1200);
  };

  const handleScanNow = async () => {
    setIsScanning(true);
    setScanLines([]);
    setAlerts([]);
    setScanProgress(0);

    const logs = [
      { text: "Initializing predictive audit engine...", status: 'INFO' as const },
      { text: "Scanning system manifest [node-alpha-42]...", status: 'INFO' as const },
      { text: "web_search: vertex ai pricing changelog 2026...", status: 'INFO' as const },
      { text: "⚡ Detected: Price drop on Gemini 2.0 Flash models", status: 'ALERT' as const },
      { text: "Analyzing request patterns for unit econ sync...", status: 'INFO' as const },
      { text: "Checking Firebase collection indexes for drift...", status: 'INFO' as const },
      { text: "⚡ High-Urgency: Cloud Run us-east1 latency spike patterns", status: 'ALERT' as const },
      { text: "Validating Stripe treasury compliance updates...", status: 'INFO' as const },
      { text: "Audit finalized. 2 critical intelligence items found.", status: 'SUCCESS' as const }
    ];

    for (let i = 0; i < logs.length; i++) {
      await new Promise(r => setTimeout(r, 600 + Math.random() * 600));
      setScanLines(prev => [...prev, logs[i]]);
      setScanProgress((i + 1) / logs.length * 100);
    }

    setAlerts([
      {
        id: '1',
        level: 'CRITICAL',
        tool: 'Vertex AI',
        title: 'Gemini Flash pricing drop — save 40%',
        summary: 'A material change in Google Cloud pricing for Gemini 2.0 Flash endpoints will reduce your monthly inference bill by $340 at current volume.',
        impact_level: 'CRITICAL',
        dollar_impact: 340,
        action: 'Migrate edges to flash-v2-001',
        source_url: 'https://cloud.google.com/blog',
        urgency_days: 18,
        details: "Current spend: $600/mo → New spend: $260/mo. The latest flash model offers 20% lower latency with identical token window.",
        checklist: ["Update config.ts model string", "Verify output token parity", "Run integration tests", "Monitor latency for 24h"]
      },
      {
        id: '2',
        level: 'WATCH',
        tool: 'Cloud Run',
        title: 'Region us-east1 latency instability',
        summary: 'Detected consistent 220ms spikes in region us-east1. Competitor architectures in us-central1 are showing 35% higher stability.',
        impact_level: 'WATCH',
        dollar_impact: 0,
        action: 'Provision failover node us-central1',
        source_url: 'https://status.cloud.google.com',
        urgency_days: 4,
        details: "Moving to multi-region adds 5% cost but ensures 99.99% availability. Latency in East-1 is currently 12% higher than your trailing average.",
        checklist: ["Provision Central-1 node", "Select failover policy", "Enable cross-region replication", "Automate health checks"]
      }
    ]);
    setIsScanning(false);
  };

  const openWindow = (id: string, title: string, content: React.ReactNode) => {
    setWindows(prev => {
      const existing = prev.find(w => w.id === id);
      const maxZ = Math.max(0, ...prev.map(win => win.zIndex));
      if (existing) {
        return prev.map(w => w.id === id ? { ...w, zIndex: maxZ + 1 } : w);
      }
      return [...prev, {
        id, title, content,
        x: 100 + prev.length * 24,
        y: 100 + prev.length * 24,
        zIndex: maxZ + 1
      }];
    });
  };

  const closeWindow = (id: string) => setWindows(prev => prev.filter(w => w.id !== id));

  return (
    <div className="min-h-screen bg-void text-text-secondary select-none font-sans overflow-hidden">
      <ParticleBackground />
      
      {/* Visual Identity Overlays */}
      <div className="fixed inset-0 pointer-events-none z-[1] opacity-[0.03] select-none mix-blend-overlay">
        <svg className="w-full h-full">
          <filter id="noise">
            <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" stitchTiles="stitch" />
            <feColorMatrix type="saturate" values="0" />
          </filter>
          <rect width="100%" height="100%" filter="url(#noise)" />
        </svg>
      </div>
      <div className="fixed inset-0 pointer-events-none z-[2] opacity-[0.04] select-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
      
      <AnimatePresence>
        {view === 'INTRO' && (
          <IntroCinematic onComplete={() => setView('ONBOARDING')} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {view === 'ONBOARDING' && (
          <div className="fixed inset-0 flex items-center justify-center bg-void z-[150]">
            <Onboarding onComplete={handleOnboardingComplete} />
          </div>
        )}
      </AnimatePresence>

      {/* Main Dashboard UI */}
      {view === 'DASHBOARD' && (
        <motion.div 
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex flex-col h-screen"
        >
          {/* Navbar */}
          <nav className="h-20 bg-surface/80 border-b border-border flex items-center justify-between px-8 z-50 backdrop-blur-md">
            <div className="flex items-center gap-12">
              <div className="flex items-center gap-3">
                 <div className="w-8 h-8 bg-accent-cyan/10 border border-accent-cyan rounded flex items-center justify-center text-accent-cyan">
                   <LayoutGrid size={18} />
                 </div>
                 <span className="text-lg font-display font-bold text-text-primary tracking-tight">STACKSENSE</span>
              </div>
              <div className="flex items-center gap-4 border-l border-border pl-12 h-6">
                <ECGHeartbeat />
                <div className="flex items-center gap-3 text-[10px] mono-data uppercase tracking-widest font-bold">
                  <div className={`w-2 h-2 rounded-full ${isScanning ? 'bg-accent-red animate-pulse' : 'bg-accent-green opacity-40'}`} />
                  <span className={isScanning ? 'text-accent-red' : 'text-text-muted'}>
                    {isScanning ? 'SCANNING LIVE' : 'SYSTEM IDLE'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-8">
              <div className="flex flex-col items-end">
                <span className="text-[9px] mono-data text-text-muted uppercase tracking-[0.2em] mb-1">Audit Interval</span>
                <span className="text-[11px] mono-data text-text-primary">Last scanned: {lastScanned}m ago</span>
              </div>
              <button 
                onClick={handleScanNow}
                disabled={isScanning}
                className="px-6 py-2.5 bg-accent-cyan/5 border border-accent-cyan/40 text-accent-cyan text-[11px] mono-data uppercase font-bold tracking-widest hover:bg-accent-cyan hover:text-void transition-all animate-pulse-cyan"
              >
                {isScanning ? 'SCANNING...' : 'SCAN NOW'}
              </button>
            </div>
          </nav>

          <div className="flex flex-1 overflow-hidden">
            {/* Sidebar Stats */}
            <aside className="hidden lg:block w-80 flex-shrink-0 border-r border-border p-8 space-y-12 bg-void/50 z-10 overflow-y-auto custom-scrollbar">
              <div className="space-y-10">
                <div>
                   <h4 className="text-[9px] mono-data text-text-muted uppercase tracking-[0.3em] mb-8 font-bold">Runway Optimization</h4>
                   <ArcGauge value={68} label="$4,080" subLabel="potential annual savings" />
                </div>

                <div className="space-y-6">
                   <h4 className="text-[9px] mono-data text-text-muted uppercase tracking-[0.3em] font-bold">Stack Health Index</h4>
                   <div className="grid grid-cols-2 gap-4">
                     {[
                       { label: 'Cost-Eff', val: 92, status: 'good' },
                       { label: 'Risk-Idx', val: 41, status: 'warn' },
                       { label: 'Modernity', val: 88, status: 'good' },
                       { label: 'Lock-In', val: 65, status: 'warn' }
                     ].map(h => (
                       <div key={h.label} className="bg-surface/50 border border-border p-4 rounded-xl text-center">
                         <div className="text-[8px] mono-data text-text-muted uppercase mb-1">{h.label}</div>
                         <div className={`text-lg font-mono font-bold ${h.status === 'good' ? 'text-accent-green' : 'text-accent-amber'}`}>{h.val}%</div>
                       </div>
                     ))}
                   </div>
                </div>

                <div className="pt-8 border-t border-border">
                   <div className="flex items-center justify-between mb-4">
                     <span className="text-[9px] mono-data text-text-muted uppercase font-bold tracking-widest">Tool Distribution</span>
                     <span className="text-[9px] mono-data text-accent-cyan">5 active</span>
                   </div>
                   <div className="space-y-2">
                     {stackData.map(tool => (
                       <div key={tool.id} className="flex items-center justify-between p-3 bg-elevated/30 border border-border/40 rounded-lg group hover:border-accent-cyan/20 transition-all">
                         <div className="flex items-center gap-3">
                           <div className="text-text-muted group-hover:text-accent-cyan transition-colors">{tool.icon}</div>
                           <span className="text-xs text-text-secondary group-hover:text-text-primary transition-colors">{tool.name}</span>
                         </div>
                         <div className={`w-1 h-1 rounded-full ${tool.health > 80 ? 'bg-accent-green' : 'bg-accent-amber'}`} />
                       </div>
                     ))}
                   </div>
                </div>
              </div>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 overflow-y-auto custom-scrollbar p-6 md:p-12 bg-[#020810]/40 z-10">
              <div className="max-w-4xl mx-auto space-y-12">
                {/* Terminal Section */}
                {(isScanning || scanLines.length > 0) && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-[#020810] border border-accent-cyan/10 rounded-xl overflow-hidden shadow-2xl"
                  >
                    <div className="bg-surface/50 border-b border-border h-10 flex items-center justify-between px-5">
                       <div className="flex gap-2">
                         <div className="w-2.5 h-2.5 rounded-full bg-accent-red/40" />
                         <div className="w-2.5 h-2.5 rounded-full bg-accent-amber/40" />
                         <div className="w-2.5 h-2.5 rounded-full bg-accent-green/40" />
                       </div>
                       <div className="flex items-center gap-4">
                         <div className="flex items-center gap-1">
                           {[0.4, 0.6, 0.5, 0.7, 0.45].map((d, i) => (
                             <motion.div 
                               key={i}
                               animate={{ height: isScanning ? [4, 16, 4] : [4, 4, 4] }}
                               transition={{ duration: d, repeat: Infinity }}
                               className="w-1 bg-accent-cyan rounded-full"
                             />
                           ))}
                         </div>
                         <span className="mono-data text-[10px] text-text-muted tracking-[0.2em] font-bold uppercase">Audit Terminal v1.0</span>
                       </div>
                       <div className="w-10" />
                    </div>
                    <div className="p-8 h-[320px] overflow-y-auto custom-scrollbar font-mono text-[11px] leading-relaxed space-y-2 crt-flicker">
                      {scanLines.map((line, i) => (
                        <div key={i} className={`flex gap-4 ${line.status === 'ALERT' ? 'text-accent-amber' : line.status === 'SUCCESS' ? 'text-accent-green font-bold' : 'text-terminal-green'}`}>
                          <span className="text-text-muted opacity-30 select-none">[{new Date().toLocaleTimeString('en-GB')}]</span>
                          <span>{line.text}</span>
                        </div>
                      ))}
                      {isScanning && <span className="w-2 h-4 bg-accent-cyan/80 inline-block animate-pulse align-middle ml-2" />}
                    </div>
                  </motion.div>
                )}

                {/* Results Section */}
                {alerts.length > 0 && !isScanning && (
                  <div className="space-y-8 animate-alert-card-in">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Activity className="text-accent-cyan" size={24} />
                        <h2 className="text-2xl font-display font-medium tracking-tight">Intelligence Feed</h2>
                      </div>
                      <div className="flex items-center gap-2 px-3 py-1 bg-accent-cyan/5 border border-accent-cyan/20 rounded-full">
                        <span className="text-[9px] mono-data text-accent-cyan uppercase font-bold tracking-widest">{alerts.length} NEW FINDINGS</span>
                      </div>
                    </div>
                    <div className="grid gap-8">
                      {alerts.map((alert, i) => (
                        <AlertCard 
                          key={alert.id} 
                          alert={alert} 
                          index={i} 
                          onOpenDetail={(a) => openWindow(`alert-${a.id}`, `Detail: ${a.tool}`, (
                            <div className="space-y-6">
                              <h4 className="text-lg font-bold text-text-primary">{a.title}</h4>
                              <p className="text-sm text-text-secondary leading-relaxed">{a.details}</p>
                              <div className="bg-void p-4 border border-border rounded-lg grid grid-cols-2 gap-4">
                                <div>
                                  <div className="text-[9px] mono-data text-text-muted uppercase mb-1">Monthly Saved</div>
                                  <div className="text-xl font-bold text-accent-green">${a.dollar_impact}</div>
                                </div>
                                <div>
                                  <div className="text-[9px] mono-data text-text-muted uppercase mb-1">Annual Savings</div>
                                  <div className="text-xl font-bold text-accent-cyan">${a.dollar_impact * 12}</div>
                                </div>
                              </div>
                              <div className="space-y-3">
                                 <div className="text-[10px] mono-data text-text-muted uppercase font-bold tracking-widest">Migration Path</div>
                                 {a.checklist?.map((item, i) => (
                                   <label key={i} className="flex items-center gap-3 p-3 bg-surface border border-border rounded-lg cursor-pointer hover:border-accent-cyan/30 transition-all">
                                     <input type="checkbox" className="w-4 h-4 rounded border-border bg-void text-accent-cyan focus:ring-accent-cyan focus:ring-offset-void transition-all" />
                                     <span className="text-xs text-text-secondary">{item}</span>
                                   </label>
                                 ))}
                              </div>
                              <button className="w-full py-4 bg-accent-cyan/10 border border-accent-cyan/30 text-accent-cyan text-[10px] mono-data uppercase font-bold tracking-widest hover:bg-accent-cyan hover:text-void transition-all flex items-center justify-center gap-2">
                                <MessageSquare size={14} />
                                Verify with AI Intelligence
                              </button>
                            </div>
                          ))}
                        />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </main>
          </div>

          {/* Floating UI Elements */}
          <div className="fixed bottom-8 left-1/2 -translate-x-1/2 flex items-center justify-center pointer-events-none z-[100] w-full">
            <button 
              onClick={() => setIsPaletteOpen(true)}
              className="px-6 py-3 bg-surface/90 border border-border text-text-muted hover:text-accent-cyan hover:border-accent-cyan/40 transition-all rounded-full flex items-center gap-3 backdrop-blur-md pointer-events-auto shadow-2xl"
            >
              <Command size={16} />
              <span className="text-[10px] mono-data font-bold uppercase tracking-widest">Ask anything (⌘K)</span>
            </button>
          </div>

          <div className="fixed bottom-6 right-6 flex flex-col items-end gap-3 z-[100]">
             <AnimatePresence>
               {inspectorOpen && (
                 <motion.div
                   initial={{ opacity: 0, scale: 0.95, transformOrigin: 'bottom right' }}
                   animate={{ opacity: 1, scale: 1 }}
                   exit={{ opacity: 0, scale: 0.95 }}
                   className="w-64 bg-surface border border-border rounded-xl shadow-2xl p-6 mb-2 overflow-hidden"
                 >
                   <div className="flex items-center justify-between mb-6">
                     <span className="text-[10px] mono-data text-text-muted uppercase tracking-widest font-bold">Stack Monitor</span>
                     <button onClick={() => setInspectorOpen(false)} className="text-text-muted hover:text-text-primary transition-colors">
                       <ChevronDown size={14} />
                     </button>
                   </div>
                   <div className="space-y-4">
                     {stackData.map(tool => (
                       <button 
                         key={tool.id}
                         onClick={() => openWindow(`tool-${tool.id}`, `Inspect: ${tool.name}`, (
                           <div className="space-y-6">
                             <div className="flex items-center gap-4">
                               <div className="w-12 h-12 bg-void border border-border rounded-xl flex items-center justify-center text-accent-cyan">
                                 {tool.icon}
                               </div>
                               <div>
                                 <h4 className="text-lg font-bold text-text-primary">{tool.name}</h4>
                                 <span className="text-[10px] mono-data text-text-muted uppercase tracking-widest">{tool.category}</span>
                               </div>
                             </div>
                             <div className="grid grid-cols-2 gap-4">
                               <div className="bg-void p-3 border border-border rounded-lg text-center">
                                 <div className="text-[8px] mono-data text-text-muted uppercase mb-1">Health</div>
                                 <div className={`text-xl font-mono font-bold ${tool.health > 80 ? 'text-accent-green' : 'text-accent-amber'}`}>{tool.health}%</div>
                               </div>
                               <div className="bg-void p-3 border border-border rounded-lg text-center">
                                 <div className="text-[8px] mono-data text-text-muted uppercase mb-1">Audit Flux</div>
                                 <div className="text-xl font-mono font-bold text-text-primary">±2.4%</div>
                               </div>
                             </div>
                             <p className="text-xs text-text-secondary leading-relaxed border-t border-border pt-4">
                               Resource usage for {tool.name} is within 15% of historical median. Last scanned 4 minutes ago. No critical drift detected in the current micro-cycle.
                             </p>
                           </div>
                         ))}
                         className="w-full flex items-center justify-between p-3 bg-void border border-border hover:border-accent-cyan/20 transition-all rounded-lg group"
                       >
                         <div className="flex items-center gap-3">
                           <div className="text-text-muted group-hover:text-accent-cyan transition-all">{tool.icon}</div>
                           <span className="text-[11px] text-text-secondary font-medium">{tool.name}</span>
                         </div>
                         <div className={`w-1.5 h-1.5 rounded-full ${tool.health > 80 ? 'bg-accent-green' : 'bg-accent-amber'} animate-pulse`} />
                       </button>
                     ))}
                   </div>
                 </motion.div>
               )}
             </AnimatePresence>
             <button 
               onClick={() => setInspectorOpen(!inspectorOpen)}
               className="flex items-center gap-3 px-6 py-3 bg-surface border border-accent-cyan/20 rounded-full shadow-2xl hover:border-accent-cyan transition-all group"
             >
               <div className="w-2 h-2 rounded-full bg-accent-green animate-pulse" />
               <span className="mono-data text-[10px] text-text-primary uppercase tracking-widest font-bold group-hover:text-accent-cyan transition-colors">
                 ● 5 tools monitored
               </span>
             </button>
          </div>

          {/* Floating Windows Containers */}
          <AnimatePresence>
            {windows.map(win => (
              <DraggableWindow 
                key={win.id} 
                window={win} 
                onClose={() => closeWindow(win.id)} 
                onFocus={() => {
                  setWindows(prev => {
                    const maxZ = Math.max(0, ...prev.map(w => w.zIndex));
                    return prev.map(w => w.id === win.id ? { ...w, zIndex: maxZ + 1 } : w);
                  });
                }}
              />
            ))}
          </AnimatePresence>

          <CommandPaletteOverlay 
            isOpen={isPaletteOpen} 
            onClose={() => setIsPaletteOpen(false)} 
          />
        </motion.div>
      )}
    </div>
  );
}

const DraggableWindow: React.FC<{ window: FloatingWindow; onClose: () => void; onFocus: () => void }> = ({ window, onClose, onFocus }) => {
  const [pos, setPos] = useState({ x: window.x, y: window.y });
  const [isDragging, setIsDragging] = useState(false);
  const dragRef = useRef({ startX: 0, startY: 0, startXP: 0, startYP: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    onFocus();
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startXP: pos.x,
      startYP: pos.y
    };
  };

  useEffect(() => {
    const handleMove = (e: MouseEvent) => {
      if (!isDragging) return;
      setPos({
        x: dragRef.current.startXP + (e.clientX - dragRef.current.startX),
        y: dragRef.current.startYP + (e.clientY - dragRef.current.startY)
      });
    };
    const handleUp = () => setIsDragging(false);
    
    if (isDragging) {
      document.addEventListener('mousemove', handleMove);
      document.addEventListener('mouseup', handleUp);
    }
    return () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleUp);
    };
  }, [isDragging]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      style={{ left: pos.x, top: pos.y, zIndex: window.zIndex }}
      className="fixed w-[380px] bg-void border border-accent-cyan/20 rounded-xl shadow-[0_16px_48px_rgba(0,0,0,0.6)] overflow-hidden flex flex-col z-[1000]"
    >
      <div 
        onMouseDown={handleMouseDown}
        className="h-10 bg-surface/80 border-b border-border flex items-center justify-between px-4 cursor-move select-none"
      >
        <span className="text-[9px] mono-data text-accent-cyan font-bold uppercase tracking-widest">{window.title}</span>
        <button onClick={onClose} className="text-text-muted hover:text-text-primary transition-colors">
          <X size={14} />
        </button>
      </div>
      <div className="p-6 overflow-y-auto max-h-[420px] custom-scrollbar">
        {window.content}
      </div>
    </motion.div>
  );
};

const CommandPaletteOverlay = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!query) return;
    setIsLoading(true);
    setResponse("");

    try {
      const result = await ai.models.generateContentStream({
        model: "gemini-3-flash-preview",
        contents: `founder query: ${query}\n\nContext: Founder tech stack includes Vertex AI, Firebase, Cloud Run, Pinecone, Stripe. Current alerts include Gemini Flash price drop ($340/mo savings). User's concern: cost/breaking changes.\n\nReply as StackPulse Intelligence, expert technical co-founder. Concise, actionable advice.`
      });
      
      for await (const chunk of result) {
        setResponse(prev => prev + (chunk.text || ""));
      }
    } catch (e) {
      setResponse("AI diagnostic failed. Check your API configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[500] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-void/85 backdrop-blur-sm"
          />
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="relative w-full max-w-[560px] bg-elevated border border-accent-cyan/30 rounded-2xl shadow-2xl p-8 overflow-hidden"
          >
            <div className="flex items-center gap-4 mb-8">
              <span className="text-accent-cyan opacity-40"><Command size={20} /></span>
              <input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask StackSense anything..."
                className="w-full bg-transparent border-none text-text-primary text-base font-mono placeholder:text-text-muted focus:ring-0 leading-tight"
              />
              <div className="text-[10px] mono-data text-text-muted bg-surface px-2 py-1 border border-border rounded">ESC</div>
            </div>

            <div className="space-y-2 mb-8">
               <div className="text-[9px] mono-data text-text-muted uppercase tracking-widest font-bold mb-3">Quick Actions</div>
               <div className="flex flex-wrap gap-2">
                 {['Critical Alerts', 'Savings Calc', 'Urgent Mode', 'Stack Health'].map(act => (
                   <button 
                    key={act}
                    onClick={() => setQuery(act)}
                    className="px-3 py-1.5 bg-void border border-border rounded-lg text-xs text-text-secondary hover:text-accent-cyan hover:border-accent-cyan/30 transition-all"
                   >
                     {act}
                   </button>
                 ))}
               </div>
            </div>

            {(isLoading || response) && (
              <div className="mt-8 pt-8 border-t border-border max-h-[300px] overflow-y-auto custom-scrollbar">
                <div className="flex items-center gap-2 mb-4 text-accent-cyan">
                   <div className="w-1.5 h-1.5 rounded-full bg-accent-cyan animate-pulse" />
                   <span className="text-[10px] mono-data font-bold uppercase tracking-widest">StackPulse Stream</span>
                </div>
                <div className="text-sm text-text-secondary leading-relaxed space-y-4">
                  {response || (
                    <div className="flex flex-col gap-2">
                      <div className="h-2 w-32 bg-border animate-pulse rounded" />
                      <div className="h-2 w-48 bg-border animate-pulse rounded" />
                    </div>
                  )}
                </div>
              </div>
            )}
            
            <div className="mt-8 flex justify-end">
               <span className="text-[9px] mono-data text-text-muted opacity-40 uppercase tracking-widest italic">Powered by Claude & Gemini Engine v4.2</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
